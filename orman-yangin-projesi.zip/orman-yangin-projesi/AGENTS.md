# Devir notu (yapay zekâ / geliştirici için)

## Bağlam
- Kullanıcı Türkiye'de bir **TÜBİTAK proje** hazırlıyor. Doküman, arayüz metni ve rapor **Türkçe**; kod tanımlayıcıları İngilizce.
- Fikir: bölgelere ayrılmış ormanda, bölgeler arası **su püskürtme hatları**; yangın komşu bölgeye sıçramadan hatlar otomatik açılır.
- Vurgu: sadece hat tasarımı değil, **akıllı kontrolün hangi koşulda nasıl çalıştığını deneysel veriyle** göstermek.
- Araştırma sorusu (taslak): "Rüzgâr yönü ve yakıt nemine göre devreye giren akıllı kontrol, tüm hatları açan veya kontrolsüz duruma kıyasla, yangının komşu bölgeye geçme olasılığını ve su tüketimini nasıl etkiler?" Ayrıntı: `docs/arastirma-plani.md`.

## Mevcut durum
- `engine.py` vektörleşmiş (numpy) hücresel otomat. Izgara 60x96, 4x3 bölge, 17 hat (dikey 9 + yatay 8), hat bandı 2 hücre.
- Hücre türleri: 0 su, 1 yanmaz (çıplak/yol/yerleşim), 2 orman, 3 otlak. Hat aktifken bant ıslanır (`wet=1`), tutuşma olasılığı `(1-0.95*wet)` ile düşer, `wet>0.5` hücreler %25 olasılıkla söner.
- Eğim terimi var (`elevation` verilirse) ama gerçek DEM henüz bağlanmadı.
- `web/legacy.html`: aynı modelin JS sürümü (Esri uydu karoları + OSM arazi düzeltmesi). Tarayıcıda dosya olarak açılır; claude.ai'de yayınlanan sayfada dış harita yüklenmez.

## Yapılacaklar (öncelik sırasıyla)
1. `data.py::rasterize_osm` çıktısını `server.py` içine bağla: seçilen bbox → yakıt ızgarası → `Sim`.
2. DEM ekle (Copernicus DEM veya AWS Terrain Tiles) → `elevation`; eğim etkisini test et.
3. Kıvılcım sıçraması (spotting) ve sensör gecikmesi/arıza modeli ekle.
4. Yeni web arayüzü: MapLibre GL (eğimli 3D uydu görünümü), `/api/simulate` sonucunu katman olarak animasyonla göster. `web/legacy.html` arayüz referansıdır (canlı durum şeridi, bölge/hat çipleri, olay akışı).
5. Doğrulama: NASA FIRMS ile geçmiş bir yangın (ör. 2021 Marmaris/Manavgat) ile model örtüşmesini ölç.
6. Maket prototipten ölçülen ıslak yakıt tutuşma düşüşünü `engine.py` parametresine bağla.

## Kararlar ve kısıtlar (değiştirmeyin, önce kullanıcıya sorun)
- **Google Earth/Google Maps görüntüsü analiz edilmez** (şartlar yasaklıyor, API ücretli). Görsel için Esri World Imagery; analiz için OSM, ESA WorldCover, Copernicus DEM.
- Her sonuç **tekrarlı** (en az 20 tohum) ve ortalama + yayılımla raporlanır; tek koşuya dayanan iddia yok.
- Modelin sınırlılıkları dürüstçe belgelenir ("hatasız" iddiası yok).
- Testler: `pytest`. Motor değişince `tests/test_engine.py` yeşil kalmalı.

## Kod sözleşmesi
- Motor deterministik: aynı `seed` aynı sonuç. Rastgelelik yalnızca `Sim.rng`.
- Rüzgâr yönü = **esme yönü** (0 = kuzeye doğru, 90 = doğuya). Open-Meteo "geldiği yön" verir; `data.py` 180° çevirir.
- Metrikler: `burnt_pct`, `zones_hit`, `water`, `extinguished`, `steps` (`Sim.metrics()`).

## İlk deney bulgusu (3 tekrar, sentetik arazi; ciddi sonuç için --runs 20+)
- Kontrolsüz: ~%49 yanıyor, 8 bölgeye yayılıyor. Hatlı stratejiler yanan alanı ~%4-11'e indiriyor.
- "Yanan bölge çevresi" ≈ "Tüm hatlar" korumasını **~5 kat az suyla** sağlıyor.
- **Mevcut "Akıllı" strateji rüzgârlı koşulda (10-20 km/sa) geride** (yanan %10-11, bölge 2,3-2,5 vs. %4,3 / 1,0-1,2). Neden: rüzgâr filtresi + küçük yarıçap, yanal yayılan yangını geç yakalıyor. **İlk araştırma görevi:** yarıçapı/rüzgâr eşiğini ayarla veya yangın ilerleme yönünü tahmin eden öngörülü tetikleme ekle; sonra H2/H3'ü yeniden test et. Bu sonuç raporda dürüstçe yazılmalı (negatif bulgu da bulgudur).
- Testler elle çalıştırıldı, 6/6 geçti (sandbox'ta pytest yoktu; `pip install -r requirements.txt` sonrası `pytest`).

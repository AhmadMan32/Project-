# Orman Yangını – Akıllı Su Hattı (TÜBİTAK projesi)

Bölgelere ayrılmış ormanlarda, yangının komşu bölgelere sıçramasını sınırlamak için **otomatik devreye giren su püskürtme hatları** ve bu hatları yöneten **akıllı kontrol stratejisi**.

Proje bir "öneri" değil **test edilebilir araştırma** olmalı: hangi koşulda hangi strateji ne kadar iyi çalışıyor, deneysel veriyle gösterilecek.

## Hızlı başlangıç
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pytest                                   # motor testleri
python -m yangin_sim.experiment --runs 20 --out results.csv   # strateji karşılaştırması
uvicorn yangin_sim.server:app --reload   # API + web/ klasörü (http://127.0.0.1:8000)
```

## Klasörler
| Yol | Ne işe yarar |
|---|---|
| `yangin_sim/engine.py` | Hücresel otomat yangın motoru (rüzgâr, nem, eğim, su hatları) |
| `yangin_sim/strategies.py` | Kontrol stratejileri (kontrolsüz / tüm hatlar / yanan bölge çevresi / akıllı) |
| `yangin_sim/data.py` | Gerçek veri: Open-Meteo hava, OpenStreetMap arazi, sentetik arazi |
| `yangin_sim/experiment.py` | Toplu deney, CSV çıktısı (rapordaki tablolar buradan) |
| `yangin_sim/server.py` | FastAPI: `/api/weather`, `/api/simulate` |
| `web/legacy.html` | Tek dosyalık çalışan prototip (harita + canlı durum). Arayüzün referansı |
| `docs/arastirma-plani.md` | Araştırma sorusu, değişkenler, deney matrisi, rapor iskeleti |
| `AGENTS.md` | **Başka bir yapay zekâ/geliştirici için devir notu: önce bunu okuyun** |

## Durum
Çalışan: motor, 4 strateji, testler, deney betiği, hava verisi, OSM indirme. Eksik işler ve öncelikler `AGENTS.md` içinde.

## Uyarı
Model basitleştirilmiş bir hücresel otomattır; gerçek yangını birebir temsil etmez. Raporda sınırlılık olarak belirtilmeli, gerçek yangın verisiyle doğrulama planlanmalı.

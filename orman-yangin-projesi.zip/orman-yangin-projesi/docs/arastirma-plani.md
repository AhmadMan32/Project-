# Araştırma planı

## Araştırma sorusu (taslak)
Rüzgâr yönü/hızı ve yakıt nemine göre devreye giren akıllı kontrol, kontrolsüz veya tüm hatları açan stratejiye kıyasla, yangının komşu bölgeye geçme olasılığını ve su tüketimini nasıl etkiler?

## Hipotezler
- H1: Akıllı strateji, kontrolsüze göre yanan alanı ve sıçrama olasılığını anlamlı azaltır.
- H2: Akıllı strateji, "tüm hatlar açık"a yakın korumayı belirgin daha az suyla sağlar.
- H3: Rüzgâr hızı arttıkça sıçrama olasılığı artar; akıllı stratejinin yarar farkı en çok yüksek rüzgârda görünür.

## Değişkenler
- Bağımsız: kontrol stratejisi (4), rüzgâr hızı (0/10/20 km/sa), rüzgâr yönü (rastgele), nem (%15/%40), hat bant genişliği, sensör aralığı/gecikmesi.
- Bağımlı (ölçümler): yanan alan %, etkilenen bölge sayısı, su kullanımı, söndürülen hücre, tepki süresi.
- Sabit: arazi (aynı tohum tüm stratejilerde), başlangıç noktası.

## Deney matrisi
`python -m yangin_sim.experiment --runs 20` → `results.csv`. Her hücre için ≥20 tekrar; ortalama ± standart sapma; stratejiler eşleştirilmiş (aynı arazi/ateş noktası) karşılaştırılır. Anlamlılık için eşleştirilmiş t-testi veya Wilcoxon.

## Fiziksel prototip (küçük, güvenli)
Maket arazide sıcaklık/nem/duman sensörleri + ESP32/Arduino, mini pompa, vana. Gerçek ateş yok: ısıtıcı tel/ısı lambası ile sıcak bölge. Ölçülecek: algılama→vana açılma gecikmesi, ıslatılan şerit genişliği, ıslak/kuru yakıtta ısınma farkı. Bu sayılar simülasyon parametrelerine (`hold`, bant genişliği, ıslak yakıt tutuşma düşüşü) aktarılır.

## Doğrulama
Geçmiş yangın (NASA FIRMS) ile modelin yayılım alanı örtüşmesi (IoU). Model sınırlılıkları: kıvılcım sıçraması, eğim, gerçek yakıt yükü, sensör arızası.

## Literatür taraması şablonu
Anahtar kelimeler: wildfire sprinkler system, fuel break wetting, WUI sprinkler, wireless sensor network forest fire, Rothermel fire spread, cellular automata wildfire. Kaynaklar: Google Scholar, Scopus/WoS, Espacenet, Google Patents, TürkPatent.
| Kaynak | Yıl | Ne yapıyor | Bizden farkı |
|---|---|---|---|

## Rapor iskeleti
Özet · Giriş/problem · Literatür ve boşluk · Araştırma sorusu/hipotez · Yöntem (model, prototip) · Bulgular (tablolar/grafikler) · Tartışma ve sınırlılıklar · Sonuç · Kaynakça.

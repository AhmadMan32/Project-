import numpy as np
from yangin_sim import Sim, Weather
from yangin_sim.engine import shift


def forest():
    return np.full((60, 96), 2, np.int8)


def run(strategy, seed, ws=15):
    s = Sim(forest(), Weather(90, ws, 20), strategy=strategy, seed=seed)
    s.ignite(30, 36)
    return s.run()


def test_shift():
    a = np.arange(9).reshape(3, 3)
    assert shift(a, 1, 0)[1, 1] == a[0, 1] and shift(a, 0, -1)[1, 0] == a[1, 1]


def test_fire_spreads_without_lines():
    assert run(0, 1)["burnt_pct"] > 5


def test_deterministic():
    assert run(3, 7) == run(3, 7)


def test_no_water_without_strategy():
    assert run(0, 2)["water"] == 0


def test_smart_uses_less_water_than_all_lines():
    sm = np.mean([run(3, s)["water"] for s in range(5)])
    al = np.mean([run(1, s)["water"] for s in range(5)])
    assert sm < al


def test_lines_reduce_burnt_area():
    none = np.mean([run(0, s)["burnt_pct"] for s in range(6)])
    smart = np.mean([run(3, s)["burnt_pct"] for s in range(6)])
    assert smart < none

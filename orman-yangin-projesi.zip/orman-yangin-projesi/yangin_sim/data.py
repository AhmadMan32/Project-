"""Veri kaynakları: hava (Open-Meteo), arazi (OpenStreetMap), sentetik arazi. İnternet gerektirenler try/except ile çağrılmalı."""
import json
import urllib.parse
import urllib.request
import numpy as np


def synthetic_fuel(h=60, w=96, seed=0):
    rng = np.random.default_rng(seed)
    p, q = rng.uniform(0, 100, 2)
    y, x = np.mgrid[0:h, 0:w]
    n = np.sin(x * .11 + p) * np.cos(y * .13 + q) + np.sin((x + y) * .07 + p) + .5 * np.sin(x * .31 + q) * np.sin(y * .27 + p)
    f = np.full((h, w), 2, np.int8)
    f[n < -.5] = 3
    f[n > 1.3] = 1
    f[n < -1.2] = 0
    f[np.abs(y - h / 2 - 6 * np.sin(x * .08 + p)) < 1] = 1   # yol
    return f


def fetch_weather(lat, lon):
    """Open-Meteo anlık hava. Dönen rüzgâr yönü = ESME yönü (API 'geldiği yön' verir, 180° çevrilir)."""
    url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
           "&current=wind_speed_10m,wind_direction_10m,relative_humidity_2m&wind_speed_unit=kmh" % (lat, lon))
    c = json.load(urllib.request.urlopen(url, timeout=15))["current"]
    return {"wind_dir": (c["wind_direction_10m"] + 180) % 360, "wind_speed": c["wind_speed_10m"],
            "humidity": c["relative_humidity_2m"]}


def fetch_osm(south, west, north, east):
    b = f"{south},{west},{north},{east}"
    q = ('[out:json][timeout:25];('
         f'way["natural"~"^(wood|scrub|heath|grassland|water|bare_rock|scree)$"]({b});'
         f'way["landuse"~"^(forest|grass|meadow|farmland|orchard|residential|industrial|commercial)$"]({b});'
         f'way["highway"~"^(motorway|trunk|primary|secondary|tertiary)$"]({b});'
         f'rel["natural"~"^(wood|water)$"]({b});rel["landuse"="forest"]({b}););out geom;')
    req = urllib.request.Request("https://overpass-api.de/api/interpreter", data=("data=" + urllib.parse.quote(q)).encode())
    return json.load(urllib.request.urlopen(req, timeout=40))["elements"]


def rasterize_osm(elements, bbox, h=60, w=96, unknown=3):
    """OSM öğelerini yakıt ızgarasına çevirir (küçük alan için lineer lat/lon yaklaşımı). Bilinmeyen = `unknown`."""
    from PIL import Image, ImageDraw
    s, w0, n, e = bbox
    img = Image.new("L", (w, h), 255)
    d = ImageDraw.Draw(img)
    px = lambda p: ((p["lon"] - w0) / (e - w0) * w, (n - p["lat"]) / (n - s) * h)
    items = []
    for el in elements:
        t = el.get("tags", {})
        line = False
        if t.get("natural") == "water": c, o = 0, 2
        elif t.get("natural") == "wood" or t.get("landuse") == "forest": c, o = 2, 0
        elif t.get("natural") in ("scrub", "heath", "grassland") or t.get("landuse") in ("grass", "meadow", "farmland", "orchard"): c, o = 3, 0
        elif t.get("natural") in ("bare_rock", "scree") or t.get("landuse") in ("residential", "industrial", "commercial"): c, o = 1, 3
        elif t.get("highway"): c, o, line = 1, 4, True
        else: continue
        geoms = ([m["geometry"] for m in el.get("members", []) if m.get("role") == "outer" and "geometry" in m]
                 if el["type"] == "relation" else [el.get("geometry", [])])
        items += [(o, c, line, [px(p) for p in g]) for g in geoms if len(g) > 1]
    for o, c, line, pts in sorted(items, key=lambda i: i[0]):
        if line: d.line(pts, fill=c, width=1)
        elif pts[0] == pts[-1]: d.polygon(pts, fill=c)
    a = np.array(img, np.int8 if False else np.uint8)
    a[a == 255] = unknown
    return a.astype(np.int8)

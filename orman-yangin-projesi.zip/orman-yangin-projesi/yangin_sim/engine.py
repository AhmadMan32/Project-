"""Hücresel otomat orman yangını + su hattı motoru (numpy, deterministik)."""
from dataclasses import dataclass
import numpy as np
from . import strategies

# yakıt türleri: 0 su, 1 yanmaz, 2 orman, 3 otlak
FUEL = np.array([0, 0, .8, 1.3])
BURN_T = np.array([0, 0, 14, 5])
DIRS = [(dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1) if dy or dx]
UNBURNT, BURNING, BURNT = 0, 1, 2


@dataclass
class Weather:
    wind_dir: float = 90.0     # esme yönü (0=kuzeye doğru, 90=doğuya)
    wind_speed: float = 12.0   # km/sa
    humidity: float = 25.0     # %


@dataclass
class Line:
    name: str
    mask: np.ndarray
    cx: float
    cy: float
    half: float
    vertical: bool
    a: int
    b: int

    def distance(self, xs, ys):
        if self.vertical:
            return np.hypot(np.abs(xs - self.cx), np.maximum(0, np.abs(ys - self.cy) - self.half))
        return np.hypot(np.maximum(0, np.abs(xs - self.cx) - self.half), np.abs(ys - self.cy))


def zone_name(i, j):
    return "ABCD"[i] + str(j + 1)


def make_lines(h, w, zx=4, zy=3):
    zh, zw = h // zy, w // zx
    lines = []
    for j in range(zy):
        for i in range(zx - 1):
            x = (i + 1) * zw
            m = np.zeros((h, w), bool)
            m[j * zh:(j + 1) * zh, x - 1:x + 1] = True
            lines.append(Line(f"{zone_name(i, j)}–{zone_name(i + 1, j)}", m, x - .5, j * zh + zh / 2, zh / 2, True, j * zx + i, j * zx + i + 1))
    for j in range(zy - 1):
        for i in range(zx):
            y = (j + 1) * zh
            m = np.zeros((h, w), bool)
            m[y - 1:y + 1, i * zw:(i + 1) * zw] = True
            lines.append(Line(f"{zone_name(i, j)}–{zone_name(i, j + 1)}", m, i * zw + zw / 2, y - .5, zw / 2, False, j * zx + i, (j + 1) * zx + i))
    return lines


def shift(a, dy, dx):
    """out[y,x] = a[y-dy, x-dx] (sıfır dolgulu)."""
    h, w = a.shape
    out = np.zeros_like(a)
    out[max(dy, 0):h + min(dy, 0), max(dx, 0):w + min(dx, 0)] = a[max(-dy, 0):h + min(-dy, 0), max(-dx, 0):w + min(-dx, 0)]
    return out


class Sim:
    def __init__(self, fuel, weather=None, strategy=3, elevation=None, cell_m=30.0, seed=0,
                 zx=4, zy=3, sensor_every=3, hold=24):
        self.fuel = np.asarray(fuel, np.int8)
        self.h, self.w = self.fuel.shape
        self.weather = weather or Weather()
        self.strategy, self.cell_m, self.sensor_every, self.hold = strategy, cell_m, sensor_every, hold
        self.z = np.zeros((self.h, self.w)) if elevation is None else np.asarray(elevation, float)
        self.rng = np.random.default_rng(seed)
        self.state = np.zeros((self.h, self.w), np.int8)
        self.age = np.zeros((self.h, self.w), np.int16)
        self.wet = np.zeros((self.h, self.w))
        self.lines = make_lines(self.h, self.w, zx, zy)
        self.on = np.zeros(len(self.lines), int)
        zh, zw = self.h // zy, self.w // zx
        self.zone = (np.minimum(np.arange(self.h)[:, None] // zh, zy - 1) * zx
                     + np.minimum(np.arange(self.w)[None, :] // zw, zx - 1))
        self.zones_hit = np.zeros(zx * zy, bool)
        self.t = self.water = self.extinguished = 0

    def ignite(self, y, x):
        sl = (slice(max(y - 1, 0), y + 2), slice(max(x - 1, 0), x + 2))
        ok = (FUEL[self.fuel[sl]] > 0) & (self.state[sl] == UNBURNT)
        self.state[sl][ok] = BURNING
        self.zones_hit[self.zone[sl][ok]] = True

    @property
    def burning(self):
        return int((self.state == BURNING).sum())

    def active_lines(self):
        return [l.name for k, l in enumerate(self.lines) if self.on[k] > 0]

    def step(self):
        wv = self.weather
        a = np.radians(wv.wind_dir)
        wx, wy = np.sin(a), -np.cos(a)
        burning = self.state == BURNING
        if self.t % self.sensor_every == 0:
            trig = strategies.STRATEGIES[self.strategy](self, burning, wx, wy)
            self.on = np.where(trig, np.maximum(self.on, self.hold), self.on)
        self.wet *= .96
        self.wet[self.wet < .02] = 0
        for k, l in enumerate(self.lines):
            if self.on[k] > 0:
                self.wet[l.mask] = 1
                self.water += int(l.mask.sum())
                self.on[k] -= 1
        fuelf = FUEL[self.fuel]
        fuelable = (self.state == UNBURNT) & (fuelf > 0)
        humf = 1 - .7 * wv.humidity / 100
        ignite = np.zeros_like(burning)
        for dy, dx in DIRS:
            src = shift(burning, dy, dx)
            if not src.any():
                continue
            ln = np.hypot(dy, dx)
            dot = (dx * wx + dy * wy) / ln
            dz = self.z - shift(self.z, dy, dx)   # hedef - kaynak
            slope = np.exp(np.clip(3.5 * dz / (ln * self.cell_m), -2, 2))
            p = .12 * fuelf * np.exp(.06 * wv.wind_speed * dot) / ln * humf * slope * (1 - .95 * self.wet)
            ignite |= src & fuelable & (self.rng.random(burning.shape) < np.clip(p, 0, .95))
        self.age[burning] += 1
        ext = burning & (self.wet > .5) & (self.rng.random(burning.shape) < .25)
        burnout = burning & (self.age > BURN_T[self.fuel])
        self.extinguished += int(ext.sum())
        self.state[ext | burnout] = BURNT
        self.state[ignite] = BURNING
        self.age[ignite] = 0
        self.zones_hit[self.zone[ignite]] = True
        self.t += 1

    def run(self, max_steps=600):
        while self.t < max_steps and self.burning:
            self.step()
        return self.metrics()

    def metrics(self):
        fuelable = FUEL[self.fuel] > 0
        return {"burnt_pct": 100 * float((self.state > 0).sum()) / max(1, fuelable.sum()),
                "zones_hit": int(self.zones_hit.sum()), "water": self.water / 100,
                "extinguished": self.extinguished, "steps": self.t}

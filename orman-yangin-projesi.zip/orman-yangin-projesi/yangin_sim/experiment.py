"""Toplu deney: strateji x rüzgâr x nem x tekrar -> CSV. Rapordaki tablolar bu çıktıdan üretilir."""
import argparse
import csv
from collections import defaultdict
import numpy as np
from .data import synthetic_fuel
from .engine import Sim, Weather
from .strategies import NAMES


def run(runs=20, out="results.csv", winds=(0, 10, 20), hums=(15, 40), max_steps=600):
    rows = []
    for ws in winds:
        for hm in hums:
            for r in range(runs):
                fuel = synthetic_fuel(seed=r)
                rng = np.random.default_rng(1000 + r)
                while True:
                    y, x = int(rng.integers(5, 55)), int(rng.integers(5, 91))
                    if fuel[y, x] in (2, 3): break
                wd = float(rng.integers(0, 360))
                for s in NAMES:
                    sim = Sim(fuel, Weather(wd, ws, hm), strategy=s, seed=r)
                    sim.ignite(y, x)
                    m = sim.run(max_steps)
                    rows.append({"strategy": NAMES[s], "wind": ws, "humidity": hm, "run": r, **m})
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    agg = defaultdict(list)
    for r in rows: agg[(r["wind"], r["strategy"])].append(r)
    print("rüzgâr  strateji              yanan%  bölge  su")
    for (ws, s), v in sorted(agg.items()):
        print(f"{ws:>5}  {s:<20} {np.mean([i['burnt_pct'] for i in v]):7.1f} {np.mean([i['zones_hit'] for i in v]):6.2f} {np.mean([i['water'] for i in v]):7.1f}")
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=20)
    ap.add_argument("--out", default="results.csv")
    a = ap.parse_args()
    run(a.runs, a.out)

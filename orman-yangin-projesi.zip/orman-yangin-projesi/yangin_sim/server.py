"""FastAPI: uvicorn yangin_sim.server:app --reload"""
import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .data import fetch_weather, synthetic_fuel
from .engine import Sim, Weather

app = FastAPI(title="Orman yangını – akıllı su hattı")


class SimRequest(BaseModel):
    strategy: int = 3
    wind_dir: float = 90
    wind_speed: float = 12
    humidity: float = 25
    ignite: tuple[int, int] = (30, 36)   # (y, x)
    seed: int = 0
    max_steps: int = 600


@app.get("/api/weather")
def weather(lat: float, lon: float):
    try:
        return fetch_weather(lat, lon)
    except Exception as e:
        raise HTTPException(502, f"Hava verisi alınamadı: {e}")


@app.post("/api/simulate")
def simulate(r: SimRequest):
    # TODO (AGENTS.md #1): sentetik arazi yerine seçilen bbox'ın OSM/DEM verisi
    sim = Sim(synthetic_fuel(seed=r.seed), Weather(r.wind_dir, r.wind_speed, r.humidity), strategy=r.strategy, seed=r.seed)
    sim.ignite(*r.ignite)
    m = sim.run(r.max_steps)
    return {"metrics": m, "state": sim.state.tolist(), "fuel": sim.fuel.tolist(), "zones_hit": sim.zones_hit.tolist()}


web = os.path.join(os.path.dirname(__file__), "..", "web")
if os.path.isdir(web):
    app.mount("/", StaticFiles(directory=web, html=True), name="web")

"""Kontrol stratejileri: her biri hangi hatların tetikleneceğini bool dizisi olarak döndürür."""
import numpy as np


def none(sim, burning, wx, wy):
    return np.zeros(len(sim.lines), bool)


def all_lines(sim, burning, wx, wy):
    return np.full(len(sim.lines), bool(burning.any()))


def burning_zone_perimeter(sim, burning, wx, wy):
    zs = set(np.unique(sim.zone[burning]).tolist())
    return np.array([l.a in zs or l.b in zs for l in sim.lines])


def smart(sim, burning, wx, wy):
    """Yangın hatta yakınsa ve (rüzgâr yeterliyse) rüzgâr hatta doğru esiyorsa aç."""
    out = np.zeros(len(sim.lines), bool)
    ys, xs = np.nonzero(burning)
    if len(ys) == 0:
        return out
    ws = sim.weather.wind_speed
    radius = 4 + ws / 3
    for k, l in enumerate(sim.lines):
        near = l.distance(xs, ys) <= radius
        if ws >= 6:
            ox, oy = l.cx - xs, l.cy - ys
            n = np.hypot(ox, oy)
            n[n == 0] = 1
            near &= (ox * wx + oy * wy) / n >= -0.2
        out[k] = near.any()
    return out


STRATEGIES = {0: none, 1: all_lines, 2: burning_zone_perimeter, 3: smart}
NAMES = {0: "Kontrolsüz", 1: "Tüm hatlar", 2: "Yanan bölge çevresi", 3: "Akıllı"}
